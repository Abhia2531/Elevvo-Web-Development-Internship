const form = document.getElementById('contactForm');
const email = document.getElementById('email');
const password = document.getElementById('password');
const emailError = document.getElementById('emailError');
const passError = document.getElementById('passError');
const successMessage = document.getElementById('successMessage');

form.addEventListener('submit', function(e) {
  e.preventDefault();
  let valid = true;

  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,}$/;
  if (!email.value.match(emailPattern)) {
    emailError.textContent = "Please enter a valid email.";
    valid = false;
  } else {
    emailError.textContent = "";
  }

  if (password.value.length < 6) {
    passError.textContent = "Password must be at least 6 characters.";
    valid = false;
  } else {
    passError.textContent = "";
  }

  if (valid) {
    successMessage.textContent = "✅ Your message has been sent!";
    form.reset();
    setTimeout(() => {
      successMessage.textContent = "";
    }, 3000);
  }
});
