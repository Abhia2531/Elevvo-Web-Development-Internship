const posts = [
  { title: "AI in 2025", category: "tech", img: "t1.jpg", desc: "Exploring the rise of artificial intelligence and its impact.", date: "2025-09-21" },
  { title: "Top 10 Travel Destinations", category: "travel", img: "tr1.jpg", desc: "Must-visit places for every traveler in 2025.", date: "2025-09-15" },
  { title: "Healthy Eating Tips", category: "food", img: "f1.jpg", desc: "Improve your diet with these easy tips.", date: "2025-09-10" },
  { title: "React vs Angular", category: "tech", img: "t2.jpg", desc: "Comparing two popular frontend frameworks.", date: "2025-08-25" },
  { title: "A Weekend in Paris", category: "travel", img: "tr2.jpg", desc: "My unforgettable trip to the city of lights.", date: "2025-08-18" },
  { title: "Global Desserts", category: "food", img: "f4.jpg", desc: "A sweet journey through famous desserts from around the world.", date: "2025-05-25" },
  { title: "Street Food Around the World", category: "food", img: "f2.jpg", desc: "Discover amazing street food from different cultures.", date: "2025-08-10" },
  { title: "The Future of Smartphones", category: "tech", img: "t3.jpg", desc: "What to expect from mobile devices in the next decade.", date: "2025-07-28" },
  { title: "Hiking the Alps", category: "travel", img: "tr3.jpg", desc: "An adventure through Europe’s most stunning mountains.", date: "2025-07-12" },
  { title: "Junk Food", category: "food", img: "f3.jpg", desc: "Great taste but health compromise", date: "2025-04-10" },
  { title: "Cybersecurity in the Modern Era", category: "tech", img: "t4.jpg", desc: "How to stay safe online in a world of constant cyber threats.", date: "2025-06-15" },
];

const postsPerPage = 4;
let currentPage = 1;

function renderPosts() {
  const category = document.getElementById("categoryFilter").value;
  const searchQuery = document.getElementById("searchInput").value.toLowerCase();

  let filteredPosts = posts.filter(post => 
    (category === "all" || post.category === category) &&
    post.title.toLowerCase().includes(searchQuery)
  );

  const start = (currentPage - 1) * postsPerPage;
  const end = start + postsPerPage;
  const paginatedPosts = filteredPosts.slice(start, end);

  const blogGrid = document.getElementById("blogGrid");
  blogGrid.innerHTML = "";

  paginatedPosts.forEach(post => {
    const card = `
      <div class="blog-card">
        <img src="${post.img}" alt="${post.title}">
        <div class="blog-content">
          <h3>${post.title}</h3>
          <p>${post.desc}</p>
          <div class="date">${post.date}</div>
        </div>
      </div>
    `;
    blogGrid.innerHTML += card;
  });

  renderPagination(filteredPosts.length);
}

function renderPagination(totalPosts) {
  const totalPages = Math.ceil(totalPosts / postsPerPage);
  const pagination = document.getElementById("pagination");
  pagination.innerHTML = "";

  for (let i = 1; i <= totalPages; i++) {
    pagination.innerHTML += `
      <button onclick="goToPage(${i})" ${i === currentPage ? "disabled" : ""}>${i}</button>
    `;
  }
}

function goToPage(page) {
  currentPage = page;
  renderPosts();
}

document.getElementById("categoryFilter").addEventListener("change", () => {
  currentPage = 1;
  renderPosts();
});

document.getElementById("searchInput").addEventListener("input", () => {
  currentPage = 1;
  renderPosts();
});

renderPosts();
