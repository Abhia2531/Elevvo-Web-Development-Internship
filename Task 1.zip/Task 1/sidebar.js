const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggle-btn");
const closeBtn = document.getElementById("close-btn");

toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("active");
});

closeBtn.addEventListener("click", () => {
  sidebar.classList.remove("active");
});
